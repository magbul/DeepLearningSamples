# Last amended: 18th April, 2018
# Ref: https://radimrehurek.com/gensim/tut1.html#from-strings-to-vectors
#
# Objective: 
#         Convert tokens with each document to corresponding 'id'




%reset -f

# 1.1  gensim contains tools for Natural Language Processing
#      Module 'corpora' contains sub-modules and methods to 
#      work with text documents
from gensim import corpora

# 1.2 defaultdict is like an ordinary dict. Only that if a key does
#  not exist in the dict, then on its search it inserts that 'key'
#   with a value that is defined by an initialization function (such as int())
from collections import defaultdict

# 2. Create a sample collection (list) of documents
documents = ["Human machine interface for lab abc computer applications",
             "A survey of user opinion of computer system response time",
             "The EPS user interface management system",
             "System and human system engineering testing of EPS",
             "Relation of user perceived response time to error measurement",
             "The generation of random binary unordered trees",
             "The intersection graph of paths in trees",
             "Graph minors IV Widths of trees and well quasi ordering",
             "Graph minors A survey"]

# 2.1 Create an arbitrary list of stopwords that we do not want
stoplist = set('for a of the and to in'.split())             


# 3. Tokenize each document in the documents
texts = list([])
for document in documents:
	doc = list([])
	for word in document.lower().split():
		if word not in stoplist:
			doc.append(word)
	texts.append(doc)	

texts             # List of list. The inner list contains tokens of respective documents


# 3.1 The following code is equivalent to above nested for-loops
# Nested list comprehension
[[word  for word in document.lower().split(' ') if word not in stoplist] for document in documents ]


# 4. 
# Ref : https://www.ludovf.net/blog/python-collections-defaultdict/
#  A defaultdict is just like a regular Python dict, 
#  except that it supports an additional argument at 
#  initialization: a function. If someone attempts to
#  access a key to which no value has been assigned,
#  that function will be called (without arguments)
#  and its return value is used as the default value
#  for the key. 

# 4.1 Initialise and create an empty dictionary
#     by name of 'frequency'
frequency = defaultdict(int)

# 4.2 Get count of each word in the 'documents'
for text in texts:
    for token in text:
    	# frequency[token] will add a key 'token' to dict
    	#  (if the 'key' does not already exit) holding value '0'. 
    	#   In either case value of the key will be incremented by 1
    	# So after all the loop is completed, value of each key
    	# will show its frequency
        frequency[token] += 1		

frequency

# 4.3 Remove words that appear only once
output = list([])
for text in texts:
	tokens = list([])
	for token in text:
		if frequency[token] > 1:
			tokens.append(token)
	output.append(tokens)


print(output)

# 5. Module 'corpora.Dictionary' implements the concept of 
#     Dictionary – a mapping between words and their integer ids.
#    Ref: https://radimrehurek.com/gensim/corpora/dictionary.html
dictionary = corpora.Dictionary(output)

# 5.1
print(dictionary.token2id)         # Another function is id2token

# 5.2 Convert document into the bag-of-words (bow)
#      format ie list of (token_id, token_count) per document.
[dictionary.doc2bow(text) for text in output]

#####################################


