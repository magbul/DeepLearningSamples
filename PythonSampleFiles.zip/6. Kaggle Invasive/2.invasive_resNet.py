"""
Last amended:   8th Dec, 2018
Kaggle Project: Invasive Species Monitoring; Identify images of invasive
                hydrangea -- ResNet50 model
Ref: https://www.kaggle.com/c/invasive-species-monitoring
My folders:
             C:\Users\ashokharnal\OneDrive\Documents\kaggle_invasive
             /home/ashok/Documents/6.KaggleInvasive

Data folders:
 		e:/kaggle_invasive
		/home/ashok/Images/kaggle_invasive/train

Moodle location: 'Image Processing, classification & deep learning'
Linked files:     i)  image_manipulation.py
                  ii) distributefilesToFolders.py

Objectives:
    i)   Learn ResNet50 deep architecture
    ii)  Classify images using ResNet50
   iii)  Transfer Learning


Preparatory steps:
=================
	i) Download two files:
			 a) train.7z			   1.98GB
		    and, b) train_labels.csv.zip           6.19KB
           from:
              https://www.kaggle.com/c/invasive-species-monitoring/data

        ii) Assuming file 'train.7z' to be in 'Downloads' folder, move it to Images/kaggle_invasive/, as:

		$ cd ~
		$ mkdir /home/ashok/Images/kaggle_invasive
		$ mv /home/ashok/Downloads/train.7z  /home/ashok/Images/kaggle_invasive

        ii) Install 7z archiver:

		 $ cd ~
		 $ sudo apt-get install p7zip

	iii) Unzip train.7z, as:

		$ cd /home/ashok/Images/kaggle_invasive
		$ 7za e train.7z         # e: Extraction
 		$ cd ~

	iv) Count number of image files in folder '/Images/kaggle_invasive/train'
            There should be 2295 images

         v) Delete 'train.7z' file. It is no longer needed.

		rm /home/ashok/Images/kaggle_invasive/train.7z

	vi) Move downloaded file 'train_labels.csv.zip' to /home/ashok/Documents/6.KaggleInvasive, as:

		 mv /home/ashok/Downloads/train_labels.csv.zip   /home/ashok/Documents/6.KaggleInvasive


	vii) Unzip 'train_labels.csv.zip' file:

		$ cd /home/ashok/Documents/6.KaggleInvasive
		$ unzip
		$ cd ~

	vi) Next, open the below listed file and execute complete python code in file:

		$ cd ~

                  1.distributefilesToFolders.py


	      This will transfer files to various folders as per their labels.

        vii) Should you want to download test.7z and make predictions:	 
             About test.7z: After unzipping this file, you must create two folders
                            test within test

     OR from command line, as:

         $ cd /home/ashok/Documents/6.KaggleInvasive
         $ python distributefilesToFolders.py

	viii) Enter into tensorflow/theano virtualEnv.

	iX)   Now you can begin executing below mentioned code

"""

## 1.0 Call libraries
%reset -f

# 1.1 ResNet Application from keras
#     Ref: https://keras.io/applications/#resnet50
from keras.applications import ResNet50

# 1.2 Keras model building classes
from keras.models import Sequential
from keras.layers import Dense, Flatten, GlobalAveragePooling2D
from keras.applications.resnet50 import preprocess_input

# 1.3 Image data generator
from keras.preprocessing.image import ImageDataGenerator

# 1.4 Misc
import time, os

# Check if folder with images exists?
assert (os.path.isdir("/home/ashok/Images/kaggle_invasive")), "Problem: Folder /home/ashok/Images/kaggle_invasive does not exist"


## 2. Define constants
num_classes = 2
train_samples = 2000
validation_samples = 295
batch_size = 4
image_height = 224        # ResNet input image shape
image_width = 224
resnet_weights_path = '/home/ashok/.keras/models/resnet50_weights_tf_dim_ordering_tf_kernels_notop.h5'


## 3. Instantiate deep-learning model
# 3.1
my_new_model = Sequential()

# 3.2
# This will cause downloading of 'notop' weights if they are already not downloaded
my_new_model.add(ResNet50(include_top=False, pooling='avg', weights='imagenet'))    # Try include_top = True

# 3.3
my_new_model.summary()

# 3.4  Add a last dense layer to evaluate features
my_new_model.add(Dense(num_classes, activation='softmax'))

# 3.5 So can I see list of layers?
my_new_model.layers
len(my_new_model.layers)

# 3.6 Say no to train first layer (ResNet) model. It is already trained
my_new_model.layers[0].trainable = False

# 3.7  Configure the model with sgd optimizer
my_new_model.compile(optimizer='sgd',
                     loss='categorical_crossentropy',
                     metrics=['accuracy'])


# 4
# ImageDataGenerator: Generate batches of tensor image data with real-time data augmentation.
#  The data will be looped over (in batches) indefinitely.
#   preprocessing_function: function that will be implied on each input.
#   The function will run before any other modification on it.

# 4.1 Instantiate an ImageDataGenerator object
data_generator = ImageDataGenerator(preprocessing_function=preprocess_input)

# 4.2
# Use flow_from_directory method of ImageDataGenerator to get batches of pre-processed images
#  flow_from_directory(directory): Takes the path to a directory, and generates batches of
#    augmented/normalized data. Yields batches indefinitely, in an infinite loop.
train_generator = data_generator.flow_from_directory(
                   '/home/ashok/Images/kaggle_invasive/data',     # It should contain one subdirectory per class.
                   target_size=(image_height, image_width),       # Dimensions to which all images found will be resized.
                   batch_size=batch_size,                         # Size of the batches of data (default: 32)
                   class_mode='categorical'     # Determines type of label arrays that are returned: "categorical": 2D one-hot encoded labels
                   )

# 4.2
validation_generator = data_generator.flow_from_directory(
        '/home/ashok/Images/kaggle_invasive/valid',
        target_size=(image_height, image_width),
        class_mode='categorical')

# 5. Run model: 18 minutes
# fit_generator: Fits the model on data generated batch-by-batch by a Python generator.
# //: Integer division
start = time.time()
my_new_model.fit_generator(
        train_generator,
        epochs = 1 ,
        steps_per_epoch= train_samples//batch_size,  #Number of batches of samples to yield from generator before declaring one epoch finished
        validation_data=validation_generator,
        validation_steps= 1   # validation_samples // batch_size    #  Number of batches to yield from validation generator at the end of every epoch.
                              # It should typically be equal to the number of samples of your validation dataset
                              # divided by the batch size.
         )

end = time.time()    # 40 minutes
(end-start)/60

# 6. Quit python

# 7. Deactivate virtualEnv, as:

	$ source deactivate tensorflow


####################
