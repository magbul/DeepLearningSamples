# -*- coding: utf-8 -*-
# Last amended: 25/11/2018
# Myfolder: /home/ashok/Documents/6.KaggleInvasive
#
# Run as:
#     Unzip 'Images/kaggle_invasive/train.7z' there only (Extract here)
#   $ cd /home/ashok/Documents/6.KaggleInvasive
#   $ python distributefilesToFolders.py
#
#   If you are working in Windows, change folder paths/names
#
## 1.0 Call libraries

# 1. Reset memory
#%reset -f
# 1.1 Usual libraries
import os, re
import pandas as pd


# 1.2 Check if folder with images exists?
assert (os.path.isdir("/home/ashok/Images/kaggle_invasive")), "Problem: Folder /home/ashok/Images/kaggle_invasive does not exist"


## Define paths
# 2 Where are my train images?
trainpath = '/home/ashok/Images/kaggle_invasive/train'

# 3. Where will I store various images as per classifciation?

data_path             ='/home/ashok/Images/kaggle_invasive/data'
data_invasive_path    = data_path +"/invasive"
data_noninvasive_path = data_path + "/noninvasive"

valid_path            ='/home/ashok/Images/kaggle_invasive/valid'
valid_invasive_path   = valid_path+ "/invasive"
valid_noninvasive_path= valid_path+ "/noninvasive"

# 4. Make folders
os.mkdir(data_path)
os.mkdir(valid_path)
os.mkdir(data_invasive_path)
os.mkdir(data_noninvasive_path)
os.mkdir(valid_invasive_path)
os.mkdir(valid_noninvasive_path)

# 5. Get list of all files in a variable 'files'
os.chdir(trainpath)
files = os.listdir(trainpath)
len(files)


# 6. Read train_label file. Labels are binary--invasive or non-invasive
train_labels = pd.read_csv('/home/ashok/Documents/6.KaggleInvasive/train_labels.csv')
train_labels.head()

# 7. Transfer files to respective folders as per their labels

# 7.1 We will use 2000 files for training
#     So they go in respective folders of 'data' folder
for i in range(2000):
    # 7.2 Extract file numbers
    s = re.findall('[0-9]+', files[i])
    print(s)
    # 7.3 If label is non invasive (0)
    #     Filenames start from 1 and not from 0
    if (train_labels.iloc[int(s[0]) - 1 , 1] == 0):
        # 7.4 Move file to noninvasive folder
        fileto = 'mv ' +files[i] + " " + data_noninvasive_path + "/"
        os.system( fileto)
    else:
        # 7.5 Else move to invasive folder
        fileto = 'mv ' +files[i] + " " + data_invasive_path + "/"
        os.system( fileto)


# 8. How mnay and which files are left?
files = os.listdir(trainpath)
len(files)


# 8.1 We will use rest 295 files for validation
#     So they go in respective subfolders of 'valid' folder
for i in range(len(files)):
    s = re.findall('[0-9]+', files[i])
    if (train_labels.iloc[int(s[0]) - 1 , 1] == 0):
        fileto = 'mv ' +files[i] + " " + valid_noninvasive_path + "/"
        os.system( fileto)
    else:
        fileto = 'mv ' +files[i] + " " + valid_invasive_path + "/"
        os.system( fileto)

######################################





# Finally check that there are no more files left:
os.listdir(trainpath)

# And how many files under each data folder?
len(os.listdir(data_invasive_path))
len(os.listdir(data_noninvasive_path))
