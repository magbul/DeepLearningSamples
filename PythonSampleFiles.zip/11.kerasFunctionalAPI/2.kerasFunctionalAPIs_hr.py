"""
Last amended: 19th December, 2018

Myfolder: 		/home/ashok/Documents/11.kerasFunctionalAPI
Datafolder:		/home/ashok/.keras/datasets/hr
Data Source:   Data was picked up from Kaggle from
               https://www.kaggle.com/ludobenistant/hr-analytics
			   This is no longer available on Kaggle.

First refer the file:

Kaggle project: Predict attrition in HR

Ref:
	https://www.kaggle.com/younasm/epileptic-seizure-recognition/data
	https://keras.io/getting-started/functional-api-guide/


Objective:
		i)   Learning keras functional APIs
		ii)  Modeling for traditional multiattribute-data
		iii) Using one-dimension Conv for multiattribute-data/time-series data
		iv)  Creating branched model
		 v)  Handling categorical variables


Example 1: A Densely-connected network

The Sequential model is probably a better choice to implement a Densely connected
network, but it helps to start with something really simple.

    i)   A layer instance is callable given a tensor, and it returns a tensor.
    ii)  Input tensor(s) and output tensor(s) can then be used to define a Model.
    iii) Such a model can be trained just like Keras Sequential models.


    Also install pydot and graphviz, as below:

	$ source activate tensorflow
	$ conda install -c anaconda graphviz
    $ conda install -c anaconda pydot


"""

################ AA. Call libraries ##################
# RUN it in ipython AND NOT atom. atom hangs.
######################################################

## 1.0 Call libraries
# 1.1 Data wrangling
%reset -f
import pandas as pd
import numpy as np

#1.2 Keras libraries
from keras.layers import Input, Dense
from keras.layers import Conv1D, MaxPooling1D, Dropout, Flatten
from keras.layers.merge import concatenate
from keras.models import Model

# 1.3 Converts a class vector (integers) to binary class matrix.
#     for use with categorical_crossentropy.
from keras.utils import to_categorical, plot_model

# 1.4 sklearn libraries
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from skimage import io


# 1.4 Misc
import pydot
import matplotlib.pyplot as plt
import os
import time


################ BB. Read/Process data ##################


## 2.0 Read Data
pathToData = "/home/ashok/.keras/datasets/hr"

os.chdir(pathToData)

data = pd.read_csv("hr.csv.zip",
	               compression='infer',
                   encoding="ISO-8859-1"      # 'utf-8' gives error, hence the choice
                  )

# 2.3 Column names?
data.columns

# 2.4 Inspect the data now
data.shape
data.head()
data.tail()
data.describe()
data.info()
data.dtypes

# 2.5 Any missing value?
data.isnull().values.sum()

## Process data

# 3 No of classes in target rows
no_output_classes =len(np.unique(data['left']))
no_output_classes

data.shape
data.columns

# 3.1 Extract predictor variables only
X = data.iloc[: ,[0,1,2,3,4,5,7,8,9] ]
X.head()

# 3.2 Transform data to dummy
X = pd.get_dummies(X)
X.columns
X.head()
X.dtypes

# 3.3 Standardize explanatory variables (all columns
ss = StandardScaler()
X_new = ss.fit_transform(X)

# 3.4 Divide train/test
X_train,  X_test, y_train, y_test = train_test_split(X_new,data.left, test_size=0.33)
y_train

# 3.5
# left: class vector to be converted into a matrix (integers from 0 to num_classes).
#    Needed for softmax

y_train =to_categorical(y_train, num_classes=no_output_classes)
y_test =to_categorical(y_test , num_classes=no_output_classes)
y_train
y_test


#########################################################################################
################ CC. Python functions with multiple parameter brackets ##################
#########################################################################################

def f(a,b):
	g = a+b
	return g      # f(a,b) returns g

f(3,4)     # 7


def f(a,b):
	def g(c):
		h = a *b *c
		return h
	return g      # f(a,b) returns g. But this time g is a function

f(3,7)(4)


def f(a,b):
	a = a+ 6      # Some processing with a and b
	b = b *a      # Values of 'a' and 'b' change
	def g(c):
		h = a *b *c
		return h
	return g      # f(a,b) modifies a and b and returns 'g'
	              # Modified values of 'a' and 'b' are available to g()

f(3,7)(4)     #    (3+6) * (7 * (3+6)) * 4 =  9 * (9 * 7) * 4


# In short:
#         f(a, b) calls f with two parameters a and b
#         f(a)(b) calls f with one parameter a, which
#                 then returns another function, which
#                 is then called with one parameter b



################################################################################
######################## DD. Develop simple Dense model ########################
################################################################################


## 4.0 Develop model with keras functional API
#  4.1 This returns a tensor equivalent to 178 neurons
#      Input shape should be: (batch_size, input_dim)
#      Dimension regarding batch_size can be ignored.
#      See below as to why: (X_train.shape[1],) AND not (X_train.shape[1])
#      Also see links:
#      https://stackoverflow.com/questions/22737000/one-dimensional-array-shapes-length-vs-length-1-vs-length
#      https://stackoverflow.com/questions/44747343/keras-input-explanation-input-shape-units-batch-size-dim-etc

# 4.2 Input layer only takes data shape as an argument
#     It is always the first layer
#     So create first object
inputs = Input(shape=(X_train.shape[1],))   # No of features
type(inputs)

# 4.2 A layer instance is callable on a tensor, and returns a tensor
#     See: Python functions with multiple parameter brackets
#     Ref: https://stackoverflow.com/questions/42874825/python-functions-with-multiple-parameter-brackets
x = Dense(64, activation='relu')(inputs)
type(x)

# 4.3
x = Dense(64, activation='relu')(x)

# 4.4
final_output_layer = Dense(no_output_classes, activation='softmax')(x)

# 4.5 This creates a model that includes
#     the Input layer and three Dense layers
model = Model(inputs=inputs, outputs=final_output_layer)

# 4.6
model.compile(optimizer='rmsprop',
              loss='categorical_crossentropy',
              metrics=['accuracy'])

# 5. What is model like?
model.summary()

# 6. Train the model: 5 minutes
start = time.time()
model.fit(X_train,
          y_train,
          epochs = 100
          )
end = time.time()
print ((end-start)/60)

# 6.1 Make predictions
score = model.evaluate(X_test, y_test)
score


## 6.2 OR
start = time.time()
model.fit(X_train, y_train,
		  epochs = 100,
		  validation_data=(X_test, y_test),
          verbose = 1
		  )  # starts training
end = time.time()
print ((end-start)/60)



####################################################################
######################## EE. Develop Model 2 #######################
####################################################################


# 7

##******************************************##
# Quit ipython
# Execute AA and BB. Jump CC and DD
##******************************************##



# Example 2: A Densely-connected network with for-loop
# Ref: http://www.puzzlr.org/the-keras-functional-api-five-simple-examples/


# 7.1  Specify how many hidden layers to add (min 1)
n_layers = 5

# 7.2
#   About input_shape
#   https://stackoverflow.com/questions/44747343/keras-input-explanation-input-shape-units-batch-size-dim-etc
inputs = Input(shape=(X_train.shape[1],))


# 7.3
x = Dense(200, activation='relu')(inputs)
x = Dropout(0.4)(x)


# 7.4 Create multiple blocks of layers
for layer in range(n_layers - 1):
	x = Dense(200, activation='relu')(x)
	x = Dropout(0.3)(x)


# 7.5 Last dense (output) layer
output = Dense(2, activation='sigmoid')(x)

# 7.6 Define model
deep_n_net = Model(inputs, output)

 # 7.7 Compile. Specify essential parameters
deep_n_net.compile(optimizer = 'adam',
	               loss= 'categorical_crossentropy',
	               metrics=['accuracy']
	               )
# 7.8 Summary now
deep_n_net.summary()

# 8 Fit the model
deep_n_net.fit(X_train,
	            y_train,
	            epochs = 100,
	            verbose=1,
                validation_data = (X_test, y_test)
                )


####################################################################
######################## FF. Branched Model ########################
####################################################################

"""
##******************************************##
# Quit ipython
# Execute AA and BB. Jump CC, DD & EE
##******************************************##

https://machinelearningmastery.com/keras-functional-api-deep-learning/
https://stackoverflow.com/questions/44978768/how-do-i-shape-my-input-data-for-use-with-conv1d-in-keras

"""

##$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
## The technique does not require feature engineering
##   as features are created by convolutional network
##$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$


# 9. Define some  constants/Reshape input

# 9.1 Regarding train data
no_of_samples_tr = X_train.shape[0]             # Each row is one sample: 7705
input_features = X_train.shape[1]               # No of features: 178
channels = 1

batch_size_tr = no_of_samples_tr                # Data being less, we will
                                                # use all samples in the batch
												#  7705

# 9.2 Regarding test data
no_of_samples_test = X_test.shape[0]           # 3795
input_features = X_test.shape[1]               # No of features. 178
channels = 1
batch_size_test = no_of_samples_test           # 3795



# 9.3 Reshape input train/test data as required by Keras for conv1D
train = X_train.reshape((no_of_samples_tr  , input_features, channels))
test  = X_test.reshape(( no_of_samples_test, input_features, channels))

# 9.4 Slight detour to understanding numpy arrays
z = np.random.random(size= (4,5))   # Rank 2. Dimension across rows=4 (axis 0)
                                    #         Dimension across columns=5 (axis 1)
z
z.reshape((4,5,1))    # Rightmost index decides dimension of 'innermost'
                      #  value(s)


# 10. Start modeling: Specify input layer and its dimensions
#      Ref: https://stackoverflow.com/a/43399308
#in_layer = Input(shape= train[0].shape )    # Shape of any sample, OR
in_layer = Input(shape= (train.shape[1],1 )) # Channel must also be specified

# 10.1 First feature extractor
conv_left_branch = Conv1D(32, kernel_size=2, activation='relu')(in_layer)
pool_left_branch = MaxPooling1D(pool_size=2)(conv_left_branch)
flat_left_branch = Flatten()(pool_left_branch)
flat_left_branch ._keras_shape     # 2816

# 10.1.1 OR, look at model summary in a lttle dirty way
model = Model(in_layer, [conv_left_branch,pool_left_branch ,flat_left_branch])
model.summary()

# 10.2 Second feature extractor. It is also fed in_layer
conv_rt_branch = Conv1D(16, kernel_size=8, activation='relu')(in_layer)
pool_rt_branch = MaxPooling1D(pool_size=2)(conv_rt_branch)
flat_rt_branch = Flatten()(pool_rt_branch)
flat_rt_branch ._keras_shape     # 1360

# OR create an intermediate model


# 11. Merge feature extractors. Fully connected layer, so to say.
#     Equivalent to cbind() and flatten
full_join = concatenate([flat_left_branch, flat_rt_branch])
full_join._keras_shape          # 4176

# 11.1 First hidden layer
hidden1 = Dense(50, activation='relu')(full_join)

# 11.2 Output layer
output = Dense(no_output_classes, activation='softmax')(hidden1)


# 11.3 Create model now
model = Model(inputs=in_layer, outputs=output)


# 12. Model summary
model.summary()

# 12.1 Compile model
model.compile(optimizer = 'adam',
	               loss= 'categorical_crossentropy',
	               metrics=['accuracy']
	               )

# 12.2  Plot model graph to file and also display
#       in window
plot_model(model, to_file='shared_input_layer.png')
io.imshow('shared_input_layer.png')
plt.show()


# 12.3 Train model
start = time.time()
history = model.fit(train, y_train,
		  epochs = 70,
		  validation_data=(test, y_test),
          verbose = 1
		  )  # starts training
end = time.time()
print((end-start)/60)


# 13. Plot how accuracy is changing as per number of epochs
v = history.history['val_acc']
t = history.history['acc']
plt.plot(range(20),v)
plt.plot(range(20),t)
plt.show()



##########################################################################

"""
Difference between (length) , (length,)  and (length,1):
Ref: https://stackoverflow.com/questions/22737000/one-dimensional-array-shapes-length-vs-length-1-vs-length

In Python, (length,) is a tuple, with one 1 item.
(length) is just parenthesis around a number.
Input shape is to be given as a tuple and hence
format will be: (178,) rather than just (178).
The (length, 1) array is an array which also has
length elements, but each element itself is an
array with a single element.
Example:
a = np.array( [[1],[2],[3]] )
a.shape  =>  (3,1)         # Two dimensional array

b = np.array( [1,2,3] )
b.shape => (3,)            # One dimensional array


np.array([[.8,.1,.3],[.2, .4, .6 ],[.3, .6, .1]])
