Last amended: 19/12/2018

Ref: https://www.kaggle.com/ludobenistant/hr-analytics
     Dataset no longer available on Kaggle

Why are our best and most experienced employees leaving prematurely? Have fun with this database
and try to predict which valuable employees will leave next. Fields in the dataset include:
	Employee satisfaction level
	Last evaluation
	Number of projects
	Average monthly hours
	Time spent at the company
	Whether they have had a work accident
	Whether they have had a promotion in the last 5 years
	Sales: Departments
	Salary
	Whether the employee has left