# -*- coding: utf-8 -*-
"""
Last amended: 07/04/2018

a. Myfolder: C:\Users\ashokharnal\OneDrive\Documents\deep_learning\cifar10 image classification

b. Ref:
    https://cambridgespark.com/content/tutorials/convolutional-neural-networks-with-keras/index.html
    https://nextjournal.com/mpd/image-classification-with-keras

c. Data Source: /home/ashok/.keras/datasets (it gets downloaded, if not present)

	Objective:
		 CIFAR10 image classification with deep-learning CNN

	Enter first tensorflow virtualenv:
		$ source activate tensorflow
		$ ipython

"""



#%%                                  A. Call libraries

# 1.0 Reset memory
% reset -f


# 1.1 Import array-manipulation library
import numpy as np


# 1.2 Import keras subroutines for fetching the CIFAR-10 dataset
#     The CIFAR-10 dataset consists of 60000 32x32 colour images in 10 classes,
#      with 6000 images per class. There are 50000 training images and 10000
#       test images.  They were collected by Alex Krizhevsky, Vinod Nair, and
#         Geoffrey Hinton. Classes are: airplane, automobile, bird, cat, deer,
#          dog, frog, horse, ship, truck
from keras.datasets import cifar10

# 1.3 Basic classes for specifying and training a neural network
#     Keras has two types of models Sequential and Model Class for complex models
#     Sequential models are essentially layer-by-layer. Model Class models may
#     also have branching.
from keras.models import Sequential

# 1.3.1 Import layers that will be used in modeling
from keras.layers import Input, Convolution2D, MaxPooling2D, Dense, Dropout, Flatten

# 1.4 Keras utilities for one-hot encoding of ground truth values
from keras.utils import np_utils

# 1.5
import os
import matplotlib.pyplot as plt
# %matplotlib inline

#%%                                 B. Define needed constants

# 2.0 Set some hyperparameters

# 2.1
batch_size = 32   # in each iteration, we consider 32 training examples at once
# 2.1
num_epochs = 5    # we iterate 200 times over the entire training set
# 2.3
kernel_size = 3   # we will use 3x3 kernels throughout
# 2.4
pool_size = 2     # we will use 2x2 pooling throughout
# 2.5
conv_depth_1 = 32 # we will initially have 32 filters per conv. layer...
                  # Remember each filter filters out some structure from image data
# 2.6
conv_depth_2 = 64 # ...switching to 64 filters  the first pooling layer
# 2.7
drop_prob_1 = 0.25 # dropout after pooling with probability 0.25
# 2.8
drop_prob_2 = 0.5  # dropout in the FC layer with probability 0.5
# 2.9
hidden_size = 512  # the FC layer will have 512 neurons


#%%                     C. Fetch cifar10 images & transform

#  3. Download, unzip and divide into training/test data cifar10 images
#      By default download occurs at C:\Users\ashokharnal\.keras\datasets\
#      Or at /home/ashok/.keras/datasets ;  Downloaded file: cifar-10-batches-py.tar.gz.
#       Expanded in folder: cifar-10-batches-py
(X_train, y_train), (X_test, y_test) = cifar10.load_data()
X_train.shape              # 50000 images, 32 X 32 pixels, 3-channels

# 4. There are 50000 training examples in CIFAR-10
num_train, height, width, depth = X_train.shape

# 4.1 There are 10000 test examples in CIFAR-10
num_test = X_test.shape[0]

# 4.2 There are 10 image classes
num_classes = np.unique(y_train).shape[0]
class_names = ["airplane","automobile","bird","cat","deer","dog","frog","horse","ship","truck"]


# 4.2 There are 10 image classes
num_classes = np.unique(y_train).shape[0]

# 4.2.1 Class names are in alphabetical sequence
class_names = ["airplane","automobile","bird",
               "cat","deer","dog","frog","horse",
               "ship","truck"]

# 5. See an image
i = 1
im1 = X_train[i]    # Get an image array
# 5.1 To which class does it belong
k = class_names[y_train[i][0]]           # Result of y_train[1] is [9], an array.
print(k)
# 5.2 Plot the image
fig = plt.figure(figsize=(4,2))
plt.imshow(im1)                          # imshow() is a matplotlib method
plt.show()



# 5. Change array types and normalise
X_train = X_train.astype('float32')
X_test = X_test.astype('float32')
X_train /= np.max(X_train) # Normalise data to [0, 1] range
X_test /= np.max(X_test) # Normalise data to [0, 1] range

# 6. One-hot encode the labels
Y_train = np_utils.to_categorical(y_train, num_classes)
Y_test = np_utils.to_categorical(y_test, num_classes)

#%%                               D. Model building

# 7. Conv [32] -> Conv [32] -> Pool (with dropout on the pooling layer)
#    padding= "SAME" tries to pad evenly left and right, but if the amount
#    of columns to be added is odd, it will add the extra column to the right
model = Sequential()
model.add(Convolution2D(conv_depth_1,
                       (kernel_size, kernel_size),
                       padding='same',
                       activation='relu',
                       input_shape=(height, width, depth)
                       )
                       )
model.add(Convolution2D(conv_depth_1, (kernel_size, kernel_size), padding='same', activation='relu'))
model.add(MaxPooling2D(pool_size=(pool_size, pool_size)))
model.add(Dropout(drop_prob_1))

# 7.1 Conv [64] -> Conv [64] -> Pool (with dropout on the pooling layer)
model.add(Convolution2D(conv_depth_2, (kernel_size, kernel_size), padding='same', activation='relu'))
model.add(Convolution2D(conv_depth_2, (kernel_size, kernel_size), padding='same', activation='relu'))
model.add(MaxPooling2D(pool_size=(pool_size, pool_size)))
model.add(Dropout(drop_prob_1))

# 7.2 Now flatten to 1D, apply FC -> ReLU (with dropout) -> softmax
model.add(Flatten())
model.add(Dense(hidden_size, activation='relu'))
model.add( Dropout(drop_prob_2))
model.add( Dense(num_classes, activation='softmax'))

# 7.3 Compile model
model.compile(loss='categorical_crossentropy', # using the cross-entropy loss function
              optimizer='adam', # using the Adam optimiser
              metrics=['accuracy']) # reporting the accuracy

#%%                              E. Model training and evaluation

# 8. ...holding out 10% of the data for validation
history =model.fit(X_train, Y_train,                # Train the model using the training set...
                   batch_size=batch_size, epochs=num_epochs,
                   verbose=1, validation_split=0.1)

# 9. Evaluate the trained model on the test set!
model.evaluate(X_test, Y_test, verbose=1)

# 10. How does the model look like?
model.summary()
###################### END##
