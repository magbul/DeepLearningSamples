# Last amended: 4th July, 2019
# Ref: https://radimrehurek.com/gensim/tut1.html#from-strings-to-vectors
#
# Objective:

#         A. Convert tokens with each document to corresponding
#            'token-ids' or integer-tokens.
#            For text cleaning, pl refer wikiclustering file
#            in folder: 10.nlp_workshop/text_clustering
#            This file uses gensim for tokenization
#         B. Keras also has  Tokenizer class that can also be
#            used for integer-tokenization. See file:
#            8.rnn/3.keras_tokenizer_class.py
#         C. nltk can also tokenize. See file:
#            10.nlp_workshop/word2vec/nlp_workshop_word2vec.py


%reset -f

# 1.1  gensim contains tools for Natural Language Processing
#      Module 'corpora' contains sub-modules and methods to
#      work with text documents
from gensim import corpora

# 1.2 defaultdict is like an ordinary dict. Only that if a key does
#  not exist in the dict, then on its search it inserts that 'key'
#   with a value that is defined by an initialization function
#    (such as int()). See at the end of code: 'Dictionaries in Python'
from collections import defaultdict

# 2. Create a sample collection (list) of documents
#    See text_clustering.py file as to how to get this list
#    from folder of files or pandas dataframe
documents = ["Human machine interface for lab abc computer applications",
             "A survey of user opinion of computer system response time",
             "The EPS user interface management system",
             "System and human system engineering testing of EPS",
             "Relation of user perceived response time to error measurement",
             "The generation of random binary unordered trees",
             "The intersection graph of paths in trees",
             "Graph minors IV Widths of trees and well quasi ordering",
             "Graph minors A survey"]

# 2.1 Clean documents: See file text_clustering.py

# 2.2 Stem documents : See file text_clustering.py

# 2.3 Create an arbitrary list of stopwords that we do not want
#     Detailed list of english stopwords is available at:
#     https://gist.github.com/sebleier/554280
stoplist = set('for a of the and to in'.split())


# 3. Define our own tokenize function.
#     This function parses list of strings into
#      list of words for each element or document
#       in the document-collection
def tokenize(docs):
    tokenized = []          # Ist List: This will be a list of lists
    for document in docs:   # For each senetence in the document-collection
        tokenized_document = []  # IInd list: List of words per string or document
        for word in document.lower().split():
            if word not in stoplist:
                tokenized_document.append(word)  # Append it to a list
        tokenized.append(tokenized_document)         # Append list of words to a list
    return tokenized

texts = tokenize(documents)

texts               #  List of list. The inner list
                    #  contains tokens of respective documents


# 3.1 The following code is equivalent to above nested for-loops
# Nested list comprehension
[[word  for word in document.lower().split(' ') if word not in stoplist] for document in documents ]


# 4.
# Ref : https://www.ludovf.net/blog/python-collections-defaultdict/
#  A defaultdict is just like a regular Python dict,
#  except that it supports an additional argument at
#  initialization: a function. If someone attempts to
#  access a key to which no value has been assigned,
#  that function will be called (without arguments)
#  and its return value is used as the default value
#  for the key.

# 4.1 Initialise and create an empty dictionary
#     by name of 'frequency'
int()          # This function gives 0.
               # Use it in defaultdict
frequency = defaultdict(int)   # defaultdict(int) => key-values are int
                               # defaultdict(list) => key-values are lists
                               # Example: {'a' :['xx','yy'], 'b':['zz']}

# 4.2 Get count of each word in the 'documents'
for text in texts:
    for token in text:
    	# frequency[token] will first add a key 'token' to dict
    	#  (if the 'key' does not already exit) holding value '0'.
    	#   In either case value of the key will be incremented by 1
    	# So after all the loop is completed, value of each key
    	# will show its frequency
        frequency[token] += 1

frequency

# 4.3 Remove words that appear only once
#     So we create another list of lists
#     texts = [['he','he','to'],['to','go']]
#     frequency={'he' : 2, 'to': 2, 'go': 1}

output = list([])       # Ist list
for text in texts:
	tokens = list([])    # Inner list
	for token in text:
		if frequency[token] > 1:
			tokens.append(token)
	output.append(tokens)


# 4.4
print(output)      #     output = [['he','he','to'],['to']]

# 5. Module 'corpora.Dictionary' implements the concept of
#     Dictionary – a mapping between words and their integer ids.
#    Ref: https://radimrehurek.com/gensim/corpora/dictionary.html
dictionary = corpora.Dictionary(output)

# 5.1
dictionary      # Just informs where it is stroed in memory

# 5.2
print(dictionary.token2id)      # Another function is id2token
                                # Same as word_index in keras tokenizer class

# 5.3 Convert document into the bag-of-words (bow)
#      format ie list of (integer-tokens, token_count) per document.
bag = [dictionary.doc2bow(text) for text in output]
bag

# 5.4 Just seperate integer-tokens from frequency
id_text=[]
for doc in bag:
    doclist=[]
    for id,_ in doc:
        doclist.append(id)
    id_text.append(doclist)

id_text

#####################################
"""
Dictionaries in Python:
=======================

Module Collections has two types of dictioaries:
i) OrderedDict and ii)

OrderedDict in Python
--------------------
    An OrderedDict is a dictionary subclass that remembers
    the order that keys were first inserted. The only
    difference between dict() and OrderedDict() is that
    OrderedDict preserves the order in which the keys are inserted.
    A regular dict doesn’t track the insertion order, and iterating
    it gives the values in an arbitrary order. By contrast, the order
    the items are inserted is remembered by OrderedDict and are returned
    in that order while iterating.

defaultdict
------------
    A defaultdict works exactly like a normal dict, but it is initialized
    with a function (called “default factory”) that takes no arguments
    and provides the default value for a nonexistent key.
    A defaultdict will never raise a KeyError. Any key that does not
    exist gets the value returned by the default function.

    from collections import defaultdict
    # Create a defaultdict with an initialization
    #  function:
    ice_cream = defaultdict(lambda: 'Vanilla')
    # Insert a key-value pair
    ice_cream['Sarah'] = 'Chunky Monkey'
    ice_cream['Sarah']    # Returns 'Chunky Monkey'
    ice_cream['Joe']      # Key non-nonexistent. Returns Vanilla

"""
