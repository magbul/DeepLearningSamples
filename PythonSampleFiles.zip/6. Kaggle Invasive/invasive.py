# -*- coding: utf-8 -*-
"""
Last amended:   4th October, 2017
Kaggle Project: Invasive Species Monitoring; Identify images of invasive
                hydrangea -- Our CNN model
Ref: https://www.kaggle.com/c/invasive-species-monitoring
My folder: C:\Users\ashokharnal\OneDrive\Documents\kaggle_invasive
Data folder: e:/kaggle_invasive
Moodle location: 'Image Processing, classification & deep learning'
Linked file: image_manipulation.py

Objetives:
    i)   Developing Convolution model to label images
    ii)  Use of train_on_batch to perform
         incremental training in batches
    iii) Save model & model weights and continue to train days-after
         by first loading saved model and weights

"""
#%%                          A. Call libraries

# 1. Reset memory
%reset -f
# 1.1 Usual libraries
import os
import numpy as np
import pandas as pd

# 1.2 Library to shuffle data
import random

# 1.3 We also need to filter strings
import re

# 1.4 Install as: conda install scikit-image
#      scikit-image (or skimage) is a collection of algorithms
#       for image processing and computer vision.
from skimage import io, transform, util

# 1.5 Which keras backend is in use? Tensorflow?
from keras.backend import image_data_format

# 1.6 Keras modules to define nnet architecture
from keras.models import Sequential
from keras.layers import Convolution2D, MaxPooling2D, ZeroPadding2D
from keras.layers import Flatten, Dense, Dropout
from keras.optimizers import SGD

# 1.7 Graphics library in order to see images
import matplotlib.pyplot as plt

# 1.8 Do not want to see warnings but only errors
import warnings
warnings.filterwarnings('ignore')


#%%                            B. Define Constants

# 2 Where are my train and test images?
#trainpath = 'e:/kaggle_invasive/train/'
#testpath = 'e:/kaggle_invasive/test/'
trainpath = '/home/ashok/Images/kaggle_invasive/train/'
testpath = '/home/ashok/Images/kaggle_invasive/test/'



# 3. Check the required image input_shape
#    as per backend. It is: (batch_size, rows, columns, channels)
print(image_data_format())

# 4. Kernel memory is limited so I'm using batch of 35 images each
#    for training and 5 images for validation
batch_size = 35
n_eval = 5

# 4.1 Also in view of ltd memory, I will scale
#     images down to 150x200 pixels.
#      This will also fasten processing speed at the cost of accuracy
xpix =150
ypix = 200
ncol = 3
scaled = (xpix, ypix, ncol)


# 4.2 Number of iteration epochs
nb_epoch = 20
# 4.3 No of images from train-folder that we will use for training
trainSize = batch_size * 64 + n_eval





#%%                             C. Exploring images


# 5. Train images are here
os.chdir(trainpath)

# 6. Get full train file list
files = os.listdir(trainpath)

# 6.1 Total no of available training files
len(files)

# 7.  Preview image labels for images in train folder
#     Train label is binary--invasive or non-invasive
train_labels = pd.read_csv('/home/ashok/Documents/6.KaggleInvasive/train_labels.csv')
train_labels.head()





#%%                          D. See plant images

# 8. Preview a few noninvasive plant images
# 8.1 For 20 images
for i in range(20):
    # 8.2 Extract file numbers
    s = re.findall('[0-9]+', files[i])
    # 8.3 If label is not invasive (0)
    if (train_labels.iloc[int(s[0]),1] == 0):
        # 8.4 Show file
        plt.figure()
        io.imshow(s[0]+".jpg")


# 9. Preview a few invasive plant images
for i in range(20):
    s = re.findall('[0-9]+', files[i])
    if (train_labels.iloc[int(s[0]),1] == 1):
        plt.figure()
        io.imshow(s[0]+".jpg")


#%%                              E. Convolution network Model

# 10.
model = Sequential()
model.add(ZeroPadding2D((1, 1), input_shape=(150, 200, 3)))

model.add(Convolution2D(64, 3, 3, activation='relu'))
model.add(ZeroPadding2D((1, 1)))
model.add(Convolution2D(64, 3, 3, activation='relu'))
model.add(MaxPooling2D((2, 2), strides=(2, 2)))

model.add(ZeroPadding2D((1, 1)))
model.add(Convolution2D(128, 3, 3, activation='relu'))
model.add(ZeroPadding2D((1, 1)))
model.add(Convolution2D(128, 3, 3, activation='relu'))
model.add(MaxPooling2D((2, 2), strides=(2, 2)))

model.add(ZeroPadding2D((1, 1)))
model.add(Convolution2D(256, 3, 3, activation='relu'))
model.add(ZeroPadding2D((1, 1)))
model.add(Convolution2D(256, 3, 3, activation='relu'))
model.add(ZeroPadding2D((1, 1)))
model.add(Convolution2D(256, 3, 3, activation='relu'))
model.add(MaxPooling2D((2, 2), strides=(2, 2)))

model.add(ZeroPadding2D((1, 1)))
model.add(Convolution2D(512, 3, 3, activation='relu'))
model.add(ZeroPadding2D((1, 1)))
model.add(Convolution2D(512, 3, 3, activation='relu'))
model.add(ZeroPadding2D((1, 1)))
model.add(Convolution2D(512, 3, 3, activation='relu'))
model.add(MaxPooling2D((2, 2), strides=(2, 2)))

model.add(Flatten())
model.add(Dense(256, activation='relu'))
model.add(Dropout(0.5))
model.add(Dense(1, activation='sigmoid'))

model.compile(optimizer=SGD(lr=1e-5, momentum=0.75, nesterov=False),
              loss='binary_crossentropy', metrics=['accuracy'])


# 11. Model summary
print(model.summary())


#%%                         F. Modelling


# 12. For every epoch
for e in range(nb_epoch):
    # 12.1 Shuffle list of files in the 'files' list
    random.shuffle(files)
    # 12.2 For a 'batch_size' set of files, train model
    #      ie no of batches per epoch would be: train_size/batch_size
    #      Get filename; get fileno; get file-label; transform to array & resize
    for i in range(0, trainSize, batch_size):
        tr=[]             # Which training files are picked up; for debugging
        val=[]            # Which validation files are picked up; for debugging
        # 12.3 Create empty set of 'train'/'target' arrays
        x_train = np.empty(shape=(batch_size, xpix, ypix, ncol))
        y_train = np.empty(shape=(batch_size))
        # 12.4 Create empty set of 'validation' arrays
        x_val = np.empty(shape=(n_eval, xpix, ypix, ncol))
        y_val = np.empty(shape=(n_eval))
        # 12.5 Loop over every file in the batch
        for k in range(0,  batch_size):
            # 12.6 Get next full file name
            imfile_name = trainpath + files[i + k]
            # 12.7 Extract from filename, its number
            s = re.findall('[0-9]+', files[i+k])
            # 12.8 Convert number to integer
            s = int(s[0])
            # 12.9 For this file-number, get its invasive label value
            y_train[k] = int(train_labels.invasive.values[s-1])
            # 12.10 Read the image file into numpy array
            tr_im = io.imread(imfile_name)
            # 12.11 Resize the array-file to 'scaled' shape
            x_train[k] = transform.resize(tr_im, output_shape=scaled)
            # 12.12 Also append the file-name to our 'tr' array list
            tr.append(files[i+k])
        # 12.13 Same steps as above for next 'n_eval' validation file
        for j in range( 0, n_eval):
            # 12.14 From 'files' list, get the next file name after batch_size
            #  of files
            imfile_name = trainpath + files[i + batch_size + j]
            # 12.15 Extrat its number & convert it to integer
            s = re.findall('[0-9]+', files[i + batch_size + j])
            s = int(s[0])
            # 12.16 For this file, get its invasive label
            y_val[j] = int(train_labels.invasive.values[s-1])
            # 12.17 Read the image file into numpy array & resize it
            val_im = io.imread(imfile_name)
            x_val[j] = transform.resize(val_im, output_shape=scaled)
            # 12.18 Finally append file name to 'val' list for debugging
            val.append(files[i + batch_size + j])

        # 12.19 Change all labels from float to integer values
        y_train = y_train.astype('int64')
        y_val = y_val.astype('int64')

        # 13. Run a single gradient update on a single batch of data.
        model.train_on_batch(x_train, y_train)
        # 13.1 Evaluate on validation dataset
        acc = model.evaluate(x_val, y_val)[1]

        # 14. Print inputs and results
        print("\nep:", e , "iter: ", i,  ",acc: ", acc) # Model accuracy
        print("\nTr Imgs:", tr)                       # For debugging
        print ("\nTr img labels: ", y_train)          # For debugging
        print("\nVal Imgs: ", val)                    # For debugging
        print ("\nVal img labels: ", y_val)           # For debugging
        print("\n\n---- NEXT----")
        #input("Press Enter key")                     # For debugging



#### OR With No Shuffling ####
#     EXECUTE EITHER UPPER FOR LOOP OR FOLLOWING ONE
#     NOT BOTH

# Simple, no shuffling of train/validation files
nb_epoch = 5
for e in range(nb_epoch):
    for i in range(0, 2000, batch_size):
        x_train = np.empty(shape=(batch_size, xpix, ypix, ncol))
        y_train = np.array(train_labels.invasive.values[i:batch_size +i])
        x_val = np.empty(shape=(n_eval, xpix, ypix, ncol))
        # Index starts from 0, which is the first value
        y_val = np.array(train_labels.invasive.values[i + batch_size:i + batch_size +n_eval])
        for k in range(0,  batch_size):
            imfile = trainpath + str(i + k + 1) + '.jpg'  # frm: (i+1).jpg to (i+batch_size).jpg
                                                          #      max k is batch_size-1
            tr_im = io.imread(imfile)
            x_train[k] = transform.resize(tr_im, output_shape=scaled)
        for j in range( 0, n_eval):
            # File names starts from 1
            imfile = trainpath + str(i + n_train + j + 1) + '.jpg'
            val_im = io.imread(imfile)
            x_val[j] = transform.resize(val_im, output_shape=scaled)
        # Run a single gradient update on a single batch of data.
        model.train_on_batch(x_train, y_train)
        acc = model.evaluate(x_val, y_val)[1]
        print("----")
        print(y_val)
        print("ep:", e, ",tr_img_st", i, "val_img_st", i + batch_size + 1,"acc:", acc)

# One epoch for demonstration purposes.
# This will work
# model.fit(x_train, y_train, epochs=1, batch_size=50)
# acc = model.evaluate(x_val, y_val)[1]
# print('Evaluation accuracy:{0}'.format(round(acc, 4)))


#%%                        G. Save model for later use


#To save a Keras model into a single HDF5 file which will contain:
#  the architecture of the model, allowing to re-create the model
#  the weights of the model
#  the training configuration (loss, optimizer)
#  the state of the optimizer, allowing to resume training exactly
#   where you left off.

# We have trained for 20 epochs. Later, training for 20 more epochs
#  can progress after loading the saved weights
#   Earlier model saved after 20 epochs: model03102017
#   File size: 170322 bytes
# 15.
model.save("E:/kaggle_invasive/modelxxx")


#%%                             H. Predictions and submission


# One epoch for demonstration purposes
# model.fit(x_train, y_train, epochs=1, batch_size=50)
#acc = model.evaluate(x_val, y_val)[1]
# print('Evaluation accuracy:{0}'.format(round(acc, 4)))

# 16. Reading test sample
sample_submission = pd.read_csv("E:/kaggle_invasive/sample_submission.csv")
img_path = "E:/kaggle_invasive/test/"

test_names = []
file_paths = []

for i in range(len(sample_submission)):
    test_names.append(sample_submission.ix[i][0])
    file_paths.append( img_path + str(int(sample_submission.ix[i][0])) +'.jpg' )

test_names = np.array(test_names)

test_images = []
for file_path in file_paths:
    #read image
    img = io.imread(file_path)
    img = transform.resize(img, output_shape=scaled)
    test_images.append(img)
    path, ext = os.path.splitext( os.path.basename(file_paths[0]) )

test_images = np.array(test_images)
predictions = model.predict(test_images)

for i, name in enumerate(test_names):
    sample_submission.loc[sample_submission['name'] == name, 'invasive'] = predictions[i]

sample_submission.to_csv("E:/kaggle_invasive/submit3.csv", index=False)



#%%                                Test beds

# These un-looped lines were used to understand
#    what is happening inside loops in ' F. Modelling' above

# Test bed 1 (simple)
n_train = 30
n_eval = 5
i = 120
xpix = 150
ypix = 200
ncol = 3
scaled = (xpix, ypix, ncol)
x_train = np.empty(shape=(n_train, xpix, ypix, ncol))
x_train.shape
y_train = np.array(train_labels.invasive.values[i:n_train +i])
y_train.shape
x_val = np.empty(shape=(n_eval, xpix, ypix, ncol))
x_val.shape
y_val = np.array(train_labels.invasive.values[i + n_train:i + n_train +n_eval])
y_val.shape
for k in range(0,  n_train):
    imfile = trainpath + str(i+k+1) + '.jpg'
    tr_im = io.imread(imfile)
    print("train: " +imfile)
    #x_train[k] = transform.resize(tr_im, output_shape=scaled)
for j in range( 0, n_eval):
    imfile = trainpath + str(i+n_train+j+1) + '.jpg'
    val_im = io.imread(imfile)
    print("val:" + imfile)

print(y_val)

# Test bed 2--Shuffled images
i = 0
random.shuffle(files)
x_train = np.empty(shape=(batch_size, xpix, ypix, ncol))
#y_train = np.array(train_labels.invasive.values[i:batch_size +i])
x_val = np.empty(shape=(n_eval, xpix, ypix, ncol))
for k in range(0,  batch_size):
    imfile_name = trainpath + files[i + k]   # frm: (i+1).jpg to (i+batch_size).jpg
    s = re.findall('[0-9]+', files[i+k])
    s = int(s[0])
    y_train[k] = int(train_labels.invasive.values[s-1])
    print(imfile_name)
for j in range( 0, n_eval):
    # File names starts from 1
    imfile_name = trainpath + files[i + batch_size + j]
    s = re.findall('[0-9]+', files[i + batch_size + j])
    s = int(s[0])
    y_val[j] = int(train_labels.invasive.values[s-1])
    print("---")
    print(imfile_name)
print(y_train)
print(y_val)

######### END ##
