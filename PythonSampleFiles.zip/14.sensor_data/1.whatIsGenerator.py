# Last amended: 08/12/2018
# Myfolder: /home/ashok/Documents/2. data_augmentation
# VM: lubuntu_deeplearning
# Ref: Page 136, Chapter 5, Deeplearning with Python by Fracois Chollet
#      https://stackoverflow.com/questions/29864366/difference-between-function-and-generator

# Objective: What is python generator

# Example 1
# 1.
def mygenerator():
    i = 0
    # 1.2
    while True:
        i += 1
        yield i

# 2
for item in mygenerator():
    # 2.1
    print(item)
    # 2.2
    if item >=4:
        break

# 3.1  Another way of using generator using next()
a = mygenerator()
a
# 3.2 Start iterating
next(a)
next(a)

# 4. A generator is an iterator. It is an Object
#    one can use in 'for..in' loop. It uses 'yield'
#    to return the value.
# 4.1 So what is the difference between 'yield' and 'return'
#     each time generator() is called in the for-loop,
#     it remembers its earlier state: this is because of
#    'yield'. A 'return' does not remember the earlier
#     state.
# 4.2 In short, a generator looks like a function but
#     behaves like an iterator.


#################
# 5. Another example
#    https://realpython.com/introduction-to-python-generators/
#################


# 5.1 Execution begins at the start of the function
#     When calling next() the first time,
#     body and continues until the next yield statement
#     where the value to the right of the statement is returned,
#     subsequent calls to next() continue from the yield statement
#     to the end of the function, and loop around and continue from
#     the start of the function body until another yield is called.

# 5.2
def countdown(num):
    print('Starting')
    i = 0
    while num > 0:
        i = i+1          # Note that even value of 'i' will be remembered
        print(i)         #  between calls even though it is not 'yielded'
        yield num
        num -= 1

# 5.3
val = countdown(5)
val

# 5.4
next(val)
# 5.5
next(val)


#################
# 6. Third example
#################

from itertools import count

# itertools provide count to generate infinite stream
#  of integer. You can give start and step to tell starting
#   and stepping value for the generated stream. I am going
#    to use this in the following example.

# 6.1
for i in count(start=0, step=1):
    print(i)

# 6.2 A simple example to generate list of even numbers.
#     Build and return a list:

def find_even_number_generator(number_stream):
    for n in number_stream:
        if n % 2 == 0:
            yield n

# 6.3
for i in find_even_number_generator(count()):
    print(i)

#################################
