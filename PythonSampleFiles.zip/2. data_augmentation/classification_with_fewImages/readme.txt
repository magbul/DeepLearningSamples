Last amended: 19/09/2017
My folder: E:\cats_and_dogs
Data is from kaggle: https://www.kaggle.com/c/dogs-vs-cats/data

Folder structure on my hard-disk is:

data
	train
		cats	# 1000 images of cats
			perview
		dogs    # 1000 images of dogs


	validation
		cats	# 400 images of cats
		dogs	# 400 images of dogs

---------------------------------------------------