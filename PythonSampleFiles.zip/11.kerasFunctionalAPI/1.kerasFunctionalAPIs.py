"""
Last amended: 08/07/2019

Myfolder: 		/home/ashok/Documents/11.kerasFunctionalAPI
Datafolder:		/home/ashok/.keras/datasets/epilepticSeizureRecognition

Kaggle project: Predict epileptic seizures

Ref:
	https://www.kaggle.com/younasm/epileptic-seizure-recognition/data
	https://www.tensorflow.org/beta/guide/keras/functional


Objective:
		i)   Learning keras functional APIs
		ii)  Modeling for traditional multiattribute-data
		iii) Using one-dimension Conv for multiattribute-data/time-series data
		iv)  Creating branched model


Example 1: A Densely-connected network

The Sequential model is probably a better choice to implement a Densely connected
network, but it helps to start with something really simple.

    i)   A layer instance is callable given a tensor, and it returns a tensor.
    ii)  Input tensor(s) and output tensor(s) can then be used to define a Model.
    iii) Such a model can be trained just like Keras Sequential models.


    Also install pydot and graphviz, as below:

	$ source activate tensorflow
	$ conda install -c anaconda graphviz
    $ conda install -c anaconda pydot


"""

################ AA. Call libraries ##################
# RUN it in ipython AND NOT atom. atom hangs.
######################################################

## 1.0 Call libraries
# 1.1 Data wrangling
%reset -f
import pandas as pd
import numpy as np

#1.2 Keras libraries
from keras.layers import Input, Dense
from keras.layers import Conv1D, MaxPooling1D, Dropout, Flatten
from keras.layers.merge import concatenate
from keras.models import Model

# 1.3 Converts a class vector (integers) to binary class matrix.
#     for use with categorical_crossentropy.
from keras.utils import to_categorical, plot_model

# 1.4 sklearn libraries
from sklearn.preprocessing import StandardScaler
from sklearn.model_selection import train_test_split
from skimage import io
from sklearn.metrics import classification_report

# 1.4 Misc
import pydot
import matplotlib.pyplot as plt
import os
import time


################ BB. Read/Process data ##################


## 2.0 Read Data
pathToData = "/home/ashok/.keras/datasets/epilepticSeizureRecognition"
os.chdir(pathToData)

data = pd.read_csv("data.csv.zip",
	               compression='infer',
                   encoding="ISO-8859-1"      # 'utf-8' gives error, hence the choice
                  )

# 2.3 Column names?
data.columns

# 2.4 Inspect the data now
data.shape
data.head()
data.tail()
data.describe()
data.info()
data.dtypes

# 2.5 Any missing value?
data.isnull().values.sum()

## Process data

# 3.1 Drop first column: 'Unnamed: 0'
data.drop(['Unnamed: 0'], axis = 'columns' , inplace = True)

# 3.1.1 No of classes in target rows
no_output_classes =len(np.unique(data['y']))
no_output_classes

# 3.2 Standardize explanatory variables (all columns but column
#     at index 178th ie 179th )
X = data.iloc[ :,  : 178]
ss = StandardScaler()
X_new = ss.fit_transform(X)

# 3.3 Divide train/test
X_train,  X_test, y_train, y_test = train_test_split(X_new,data.y, test_size=0.33)
y_train

# 3.4
# y: class vector to be converted into a matrix (integers from 0 to num_classes).
# Values in y_train starts from 1. We make values start from 0
#    Needed for softmax

y_train =to_categorical(y_train - 1, num_classes=no_output_classes)
y_test =to_categorical(y_test - 1, num_classes=no_output_classes)
y_train
y_test


#########################################################################################
################ CC. Python functions with multiple parameter brackets ##################
#########################################################################################

"""
Ref: https://stackoverflow.com/a/42874845
It should be clear now that you know what f(a)(b) does, but to summarize:

  a)  Functions with multiple parameter brackets return ANOTHER function
  b)  f(a, b) calls f with two parameters a and b
  c)  f(a)(b) calls f with one parameter a, which then
      returns another function, which is then called
      with one parameter b


"""




## aa
def f(a,b):
	g = a+b
	return g      # f(a,b) returns g

f(3,4)     # 7

## bb
def f(a,b):
	def g(c):
		h = a *b *c
		return h
	return g      # f(a,b) returns function 'g'. And then g() is called
		      # with parameter '4' and value og g(4) returned

f(3,7)(4)

## cc
def f(a,b):
	a = a+ 6      # Some processing with a and b
	b = b *a      # Values of 'a' and 'b' change
	def g(c):
		h = a *b *c
		return h
	return g      # f(a,b) modifies a and b and returns 'g'
	              # Modified values of 'a' and 'b' are available to g()

f(3,7)(4)     #    (3+6) * (7 * (3+6)) * 4 =  9 * (9 * 7) * 4

k = f(3,7)     # You can execute it in two steps. First just call f()
               # It returns a function
k(4)           # Then call the returned function()

## dd
#     This code does not work
def f(a,b):
	a = a+ 6      # Some processing with a and b
	b = b *a      # Values of 'a' and 'b' change
	def g(c):
		h = a *b *c
		return h
	k = g(a)
	return k      # f(a,b) modifies a and b and returns 'g'
	              # Modified values of 'a' and 'b' are available to g()



# In short:
#         f(a, b) calls f with two parameters a and b
#         f(a)(b) calls f with one parameter a, which
#                 then returns another function, which
#                 is then called with one parameter b
#         f(a)    may also return a function



################################################################################
######################## DD. Develop simple Dense model ########################
################################################################################


## 4.0 Develop model with keras functional API
#  4.1 This returns a tensor equivalent to 178 neurons
#      Input shape should be: (batch_size, input_dim)
#      Dimension regarding batch_size can be ignored.
#      See below as to why: (X_train.shape[1],) AND not (X_train.shape[1])
#      Also see links:
#      https://stackoverflow.com/questions/22737000/one-dimensional-array-shapes-length-vs-length-1-vs-length
#      https://stackoverflow.com/questions/44747343/keras-input-explanation-input-shape-units-batch-size-dim-etc

# 4.2 Input layer only takes data shape as an argument
#     It is always the first layer

# 4.2.1    So start by creating an input node:
inputs = Input(shape=(X_train.shape[1],))   # No of features

# 4.3 What gets returned, inputs, contains information
#     about the shape and dtype of the input data that
#     you expect to feed to your model:
inputs.shape   # TensorShape([Dimension(None), Dimension(178)])

inputs.dtype

"""
Here we just specify the shape of our data: X_train.shape[1]-dimensional vectors.
None that the batch size is always omitted, we only specify the shape of each sample.
For an input meant for images of shape (32, 32, 3), we would have used:
img_inputs = keras.Input(shape=(32, 32, 3))
"""


# 4.2 A layer instance is callable on a tensor, and returns a tensor
#     See: Python functions with multiple parameter brackets
#     Ref: https://stackoverflow.com/questions/42874825/python-functions-with-multiple-parameter-brackets

# 4.2.1 Create a new node in the graph of layers by calling a
#       layer on this inputs object:
dense = Dense(64, activation='relu')
x = dense(inputs)

"""
The "layer call" action is like drawing an arrow from "inputs"
to this layer we created. We're "passing" the inputs to the
dense layer, and out we get x.
"""


# 4.3  Let's add a few more layers to our graph of layers:
x = Dense(64, activation='relu')(x)

# 4.4
final_output_layer = Dense(no_output_classes, activation='softmax')(x)

# 4.5 This creates a model that includes
#     the Input layer and three Dense layers
#     At this point, we create a Model by
#     specifying its inputs and outputs in the
#     graph of layers:
model = Model(inputs=inputs, outputs=final_output_layer)

# 4.6
model.compile(optimizer='rmsprop',
              loss='categorical_crossentropy',
              metrics=['accuracy'])

# 5. What is model like?
model.summary()


# 6. Train the model: 5 minutes
start = time.time()
model.fit(X_train,
          y_train,
          epochs = 100
          )
end = time.time()
print ((end-start)/60)

# 6.1 Make predictions
score = model.evaluate(X_test, y_test)
score


## 6.2 OR
start = time.time()
model.fit(X_train, y_train,
		  epochs = 100,
		  validation_data=(X_test, y_test),
          verbose = 1
		  )  # starts training
end = time.time()
print ((end-start)/60)



####################################################################
######################## EE. Develop Model 2 #######################
####################################################################


# 7

##******************************************##
# Quit ipython
# Execute AA and BB. Jump CC and DD
##******************************************##



# Example 2: A Densely-connected network with for-loop
# Ref: http://www.puzzlr.org/the-keras-functional-api-five-simple-examples/


# 7.1  Specify how many hidden layers to add (min 1)
n_layers = 5

# 7.2
#   About input_shape
#   https://stackoverflow.com/questions/44747343/keras-input-explanation-input-shape-units-batch-size-dim-etc
inputs = Input(shape=(178,))


# 7.3
x = Dense(200, activation='relu')(inputs)
x = Dropout(0.4)(x)


# 7.4 Create multiple blocks of layers
for layer in range(n_layers - 1):
	x = Dense(200, activation='relu')(x)
	x = Dropout(0.3)(x)


# 7.5 Last dense (output) layer
output = Dense(5, activation='sigmoid')(x)

# 7.6 Define model
deep_n_net = Model(inputs, output)

 # 7.7 Compile. Specify essential parameters
deep_n_net.compile(optimizer = 'adam',
	               loss= 'categorical_crossentropy',
	               metrics=['accuracy']
	               )
# 7.8 Summary now
deep_n_net.summary()

# 8 Fit the model
deep_n_net.fit(X_train,
	            y_train,
	            epochs = 100,
	            verbose=1,
                validation_data = (X_test, y_test)
                )


####################################################################
######################## FF. Branched Model ########################
####################################################################

"""
##******************************************##
# Quit ipython
# Execute AA and BB. Jump CC, DD & EE
##******************************************##

https://machinelearningmastery.com/keras-functional-api-deep-learning/
https://stackoverflow.com/questions/44978768/how-do-i-shape-my-input-data-for-use-with-conv1d-in-keras

"""

##$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$
## The technique does not require feature engineering
##   as features are created by convolutional network
##$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$


# 9. Define some  constants/Reshape input

# 9.1 Regarding train data
no_of_samples_tr = X_train.shape[0]             # Each row is one sample: 7705
input_features = X_train.shape[1]               # No of features: 178
channels = 1

batch_size_tr = no_of_samples_tr                # Data being less, we will
                                                # use all samples in the batch
												#  7705

# 9.2 Regarding test data
no_of_samples_test = X_test.shape[0]           # 3795
input_features = X_test.shape[1]               # No of features. 178
channels = 1
batch_size_test = no_of_samples_test           # 3795



# 9.3 Reshape input train/test data as required by Keras for conv1D
train = X_train.reshape((no_of_samples_tr  , input_features, channels))
test  = X_test.reshape(( no_of_samples_test, input_features, channels))

# 9.4 Slight detour to understanding numpy arrays
z = np.random.random(size= (4,5))   # Rank 2. Dimension across rows=4 (axis 0)
                                    #         Dimension across columns=5 (axis 1)
z
z.reshape((4,5,1))    # Rightmost index decides dimension of 'innermost'
                      #  value(s)


# 10. Start modeling: Specify input layer and its dimensions
#      Ref: https://stackoverflow.com/a/43399308
#in_layer = Input(shape= train[0].shape )    # Shape of any sample, OR
in_layer = Input(shape= (train.shape[1],1 )) # Channel must also be specified

# 10.1 First feature extractor
conv_left_branch = Conv1D(32, kernel_size=2, activation='relu')(in_layer)
pool_left_branch = MaxPooling1D(pool_size=2)(conv_left_branch)
flat_left_branch = Flatten()(pool_left_branch)
flat_left_branch ._keras_shape     # 2816

# 10.1.1 OR, look at model summary in a lttle dirty way
model = Model(in_layer, [conv_left_branch,pool_left_branch ,flat_left_branch])
model.summary()

# 10.2 Second feature extractor. It is also fed in_layer
conv_rt_branch = Conv1D(16, kernel_size=8, activation='relu')(in_layer)
pool_rt_branch = MaxPooling1D(pool_size=2)(conv_rt_branch)
flat_rt_branch = Flatten()(pool_rt_branch)
flat_rt_branch ._keras_shape     # 1360

# OR create an intermediate model


# 11. Merge feature extractors. Fully connected layer, so to say.
#     Equivalent to cbind() and flatten
full_join = concatenate([flat_left_branch, flat_rt_branch])
full_join._keras_shape          # 4176

# 11.1 First hidden layer
hidden1 = Dense(50, activation='relu')(full_join)

# 11.2 Output layer
output = Dense(no_output_classes, activation='softmax')(hidden1)


# 11.3 Create model now
model = Model(inputs=in_layer, outputs=output)


# 12. Model summary
model.summary()

# 12.1 Compile model
model.compile(optimizer = 'adam',
	               loss= 'categorical_crossentropy',
	               metrics=['accuracy']
	               )

# 12.2  Plot model graph to file and also display
#       in window
plt.figure(figsize = (12,10))
plot_model(model, to_file='shared_input_layer.png')
io.imshow('shared_input_layer.png')
plt.show()


# 12.3 Train model
start = time.time()
history = model.fit(train, y_train,
		  epochs = 20,
		  validation_data=(test, y_test),
          verbose = 1
		  )  # starts training
end = time.time()
print((end-start)/60)


# 13. Plot how accuracy is changing as per number of epochs
v = history.history['val_acc']
t = history.history['acc']
plt.plot(range(20),v)
plt.plot(range(20),t)
plt.show()

# 14. Making predictions
pred = model.predict(test)
y_actual = pd.Series(y_test[:,0])
pred[pred>0.5] = 1
pred[pred<=0.5] = 0
predicted = pd.Series(pred[:,0])
predicted.shape
pd.crosstab(y_actual, predicted)
np.sum(y_actual)
np.sum(predicted)
#  Try
print(classification_report(y_actual, predicted))



##########################################################################

"""
Difference between (length) , (length,)  and (length,1):
Ref: https://stackoverflow.com/questions/22737000/one-dimensional-array-shapes-length-vs-length-1-vs-length

In Python, (length,) is a tuple, with one 1 item.
(length) is just parenthesis around a number.
Input shape is to be given as a tuple and hence
format will be: (178,) rather than just (178).
The (length, 1) array is an array which also has
length elements, but each element itself is an
array with a single element.
Example:
a = np.array( [[1],[2],[3]] )
a.shape  =>  (3,1)         # Two dimensional array

b = np.array( [1,2,3] )
b.shape => (3,)            # One dimensional array


np.array([[.8,.1,.3],[.2, .4, .6 ],[.3, .6, .1]])
